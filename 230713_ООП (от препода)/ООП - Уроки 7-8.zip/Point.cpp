#include "Point.h"
int Point::maxX{ 150 };
int Point::maxY{ 150 };