#pragma once
class Point
{
public:
	int x;
	int y;
	static int maxX;
	static int maxY;
};
